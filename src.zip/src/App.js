import React, { Component } from "react";
import Navbar from "./Components/Navbar";
import Counters from "./Components/Counters";
import "./App.css";

class App extends Component {
  //First Phase of the Life Cycle Hook
  constructor() {
    // As a constructor, this function is only be called at the time of instance creation
    super();
    console.log("Welcome - App Constructor", this.props);
  }

  //Second Phase of the Life Cycle Hook
  componentDidMount() {
    // best method to call ajax calls

    console.log("App - mounted");
  }

  state = {
    counters: [
      { id: 1, value: 4 },
      { id: 2, value: 2 },
      { id: 3, value: 0 },
      { id: 4, value: 0 },
    ],
  };

  handleIncrement = (counter) => {
    console.log(counter);
    const counters = [...this.state.counters];
    const index = counters.indexOf(counter);
    counters[index] = { ...counter };
    counters[index].value++;
    this.setState({ counters });
  };

  handleDelete = (CounterId) => {
    const update = this.state.counters.filter((c_ID) => c_ID.id !== CounterId);

    this.setState({ counters: update }); // when we need to update if there is a change
    //in names you need to encounter overwite the old property(Data) with new one.
  };

  handleReset = () => {
    const reset = this.state.counters.map((resetV) => {
      resetV.value = 0;
      return resetV;
    });
    this.setState({ counters: reset });
  };

  render() {
    //Third Phase of the Life Cycle Hook
    console.log("App Rendered");
    return (
      <React.Fragment>
        <Navbar
          className="resetOutline"
          totalCounters={
            this.state.counters.filter((count) => count.value > 0).length
          }
        />
        <main className="container resetOnline">
          <Counters
            counters={this.state.counters}
            onReset={this.handleReset}
            onDelete={this.handleDelete}
            onIncrement={this.handleIncrement}
          />
        </main>
      </React.Fragment>
    );
  }
}

export default App;
