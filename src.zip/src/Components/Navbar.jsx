import React, { Component } from "react";

//creating the stateless fucntional components
// In stateless functional components, we need to pass the props as a parametr i.e. No need to use the "this" Operator
const Navbar = ({ totalCounters }) => {
  //To make the code more cleaner, we can use destructing arguments
  // we need to change the props as an argument into
  return (
    <nav className="navbar navbar-light bg-light">
      <span className="navbar-brand mb-0 h1">
        Total Number of Counters :
        <span className="badge badge-info badge-sm m-2 badge-pill">
          {totalCounters}
        </span>
      </span>
    </nav>
  );
};

//creating the stateless fucntional components
export default Navbar;
