import React, { Component } from "react";
import Counter from "./Counter";

class Counters extends Component {
  render() {
    const { onDelete, onReset, onIncrement, counters } = this.props; // object destructing to make the code more cleaner
    return (
      <div>
        {counters.map((counter) => (
          <Counter
            key={counter.id}
            counter={counter}
            onDelete={onDelete}
            onIncrement={onIncrement}
          />
        ))}

        <button onClick={onReset} className="btn btn-success btn-sm m-2">
          Reset
        </button>
      </div>
    );
  }
}

export default Counters;
